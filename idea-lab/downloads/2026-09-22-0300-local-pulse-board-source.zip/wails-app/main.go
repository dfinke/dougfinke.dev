package main

import (
    "embed"
    "github.com/wailsapp/wails/v2"
    "github.com/wailsapp/wails/v2/pkg/options"
    "github.com/wailsapp/wails/v2/pkg/options/assetserver"
)

//go:embed frontend
var assets embed.FS

func main() {
    app := NewApp()
    err := wails.Run(&options.App{
        Title: "Local Pulse Board",
        Width: 960,
        Height: 640,
        AssetServer: assetserver.Options{Assets: assets},
        Bind: []interface{}{app},
    })
    if err != nil { panic(err) }
}
