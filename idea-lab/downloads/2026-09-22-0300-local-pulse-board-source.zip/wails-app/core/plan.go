package core

// Service is the deliberately small PowerShell-to-Go contract.
type Service struct { Name string `json:"Name"`; State string `json:"State"`; LatencyMs int `json:"LatencyMs"`; QueueDepth int `json:"QueueDepth"` }
type Snapshot struct { GeneratedAt string `json:"GeneratedAt"`; Services []Service `json:"Services"` }

func (s Snapshot) WatchCount() int { n := 0; for _, service := range s.Services { if service.State == "Watch" { n++ } }; return n }
func (s Snapshot) TotalLatency() int { n := 0; for _, service := range s.Services { n += service.LatencyMs }; return n }
