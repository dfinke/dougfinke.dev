package main

import (
    "encoding/json"
    "fmt"
    "io"
    "localpulseboard/core"
    "os"
)

// This tiny CLI is a buildable contract check independent of the desktop runtime.
func main() {
    data, err := io.ReadAll(os.Stdin); if err != nil { panic(err) }
    var snapshot core.Snapshot
    if err := json.Unmarshal(data, &snapshot); err != nil { panic(err) }
    fmt.Printf("%d services · %d watching · %d ms total latency\n", len(snapshot.Services), snapshot.WatchCount(), snapshot.TotalLatency())
}
