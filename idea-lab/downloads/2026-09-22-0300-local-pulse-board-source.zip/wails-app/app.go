package main

import (
    "encoding/json"
    "fmt"
    "localpulseboard/core"
)

// App is the Wails binding exposed to the frontend.
type App struct{}

func NewApp() *App { return &App{} }

// Summarize accepts the exact JSON shape emitted by solution.ps1.
func (a *App) Summarize(payload string) (string, error) {
    var snapshot core.Snapshot
    if err := json.Unmarshal([]byte(payload), &snapshot); err != nil { return "", err }
    return fmt.Sprintf("%d services · %d watching · %d ms total latency", len(snapshot.Services), snapshot.WatchCount(), snapshot.TotalLatency()), nil
}
