[CmdletBinding()]
param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if (-not (Get-Command go -ErrorAction SilentlyContinue)) { throw 'Go is required. Install Go locally before building.' }
if ($CheckOnly) { go test ./...; exit $LASTEXITCODE }
if (-not (Get-Command wails -ErrorAction SilentlyContinue)) { throw 'Wails CLI is required. Install it locally before building.' }
wails build
