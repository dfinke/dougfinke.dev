import './style.css';

// The Wails binding receives the JSON string created by solution.ps1.
const sample = { GeneratedAt: '2026-09-22T07:00:00Z', Services: [
  { Name: 'Search', State: 'Ready', LatencyMs: 42, QueueDepth: 3 },
  { Name: 'Billing', State: 'Watch', LatencyMs: 118, QueueDepth: 9 },
  { Name: 'Mail', State: 'Ready', LatencyMs: 57, QueueDepth: 1 }
] };

const services = document.querySelector('#cards');
const summary = document.querySelector('#summary');
summary.textContent = `${sample.Services.length} services · ${sample.Services.filter(s => s.State === 'Watch').length} watching`;
services.innerHTML = sample.Services.map(s => `<article><strong>${s.Name}</strong><span class="${s.State.toLowerCase()}">${s.State}</span><small>${s.LatencyMs} ms · queue ${s.QueueDepth}</small></article>`).join('');
