#requires -Version 7.0
[CmdletBinding()]
param(
    # Accept fictional session objects from PowerShell.
    [Parameter(Mandatory)]
    [object[]] $Session,

    # Point to the CLI built from the included Go source.
    [Parameter(Mandatory)]
    [string] $CliPath
)

# Stop with build guidance if the source-only CLI is not present yet.
if (-not (Test-Path -LiteralPath $CliPath -PathType Leaf)) {
    throw "Build the local CLI first with .\source\build.ps1; expected '$CliPath'."
}

# Create a compact JSON request that both the CLI and Wails UI understand.
$request = [pscustomobject]@{
    sessions = @($Session | ForEach-Object {
        [pscustomobject]@{
            name    = [string]$_.Name
            track   = [string]$_.Track
            minutes = [int]$_.Minutes
        }
    })
}
$json = ConvertTo-Json -InputObject $request -Depth 6 -Compress

# Send only the structured request to the local CLI and capture its JSON result.
$responseText = $json | & $CliPath
if ($LASTEXITCODE -ne 0) {
    throw "The local planning CLI returned exit code $LASTEXITCODE."
}

# Parse and display the structured result from the shared Go engine.
$response = ConvertFrom-Json -InputObject ($responseText -join [Environment]::NewLine)
$response