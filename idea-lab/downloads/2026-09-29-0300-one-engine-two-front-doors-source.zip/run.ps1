#requires -Version 7.0
# Use the platform-specific executable name created by the source build.
$cliPath = Join-Path $PSScriptRoot 'source/bin/plancli'
if ($IsWindows) {
    $cliPath += '.exe'
}

# Read the fictional session plan and call the locally built Go CLI.
$items = @(
    [pscustomobject]@{ Name = 'Prompt Lab'; Track = 'AI'; Minutes = 45 }
    [pscustomobject]@{ Name = 'PowerShell Games'; Track = 'Creative'; Minutes = 30 }
    [pscustomobject]@{ Name = 'Excel Stories'; Track = 'Data'; Minutes = 40 }
)

# Run the generated PowerShell contract; it requires the local CLI binary.
& (Join-Path $PSScriptRoot 'solution.ps1') -Session $items -CliPath $cliPath