# One Engine, Two Front Doors

One Go core can power a Wails window and a PowerShell-friendly CLI. Explore the shared JSON contract and build it locally.

The bundle includes a Wails desktop UI, the same planning logic behind a local CLI, and a PowerShell example that sends structured JSON and reads a structured result.

This lab is source-only. No compiled executable is included. PowerShell and Wails integration were not run in the cloud; build locally with source/build.ps1.