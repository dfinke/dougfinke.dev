package plan

import "sort"

// Session is one fictional workshop session.
type Session struct {
	Name    string `json:"name"`
	Track   string `json:"track"`
	Minutes int    `json:"minutes"`
}

// Request carries the same JSON shape sent by PowerShell and the CLI.
type Request struct {
	Sessions []Session `json:"sessions"`
}

// Result is a small summary that can be rendered in a UI or consumed by PowerShell.
type Result struct {
	Count        int            `json:"count"`
	TotalMinutes int            `json:"totalMinutes"`
	ByTrack      map[string]int `json:"byTrack"`
}

// Analyze totals session time and groups it by track.
func Analyze(request Request) Result {
	result := Result{
		Count:   len(request.Sessions),
		ByTrack: make(map[string]int),
	}
	for _, session := range request.Sessions {
		result.TotalMinutes += session.Minutes
		result.ByTrack[session.Track] += session.Minutes
	}
	return result
}

// DemoRequest returns a stable set of fictional sessions for the desktop UI.
func DemoRequest() Request {
	return Request{Sessions: []Session{
		{Name: "Prompt Lab", Track: "AI", Minutes: 45},
		{Name: "PowerShell Games", Track: "Creative", Minutes: 30},
		{Name: "Excel Stories", Track: "Data", Minutes: 40},
	}}
}

// TrackNames returns sorted names for a consistent user interface.
func TrackNames(result Result) []string {
	names := make([]string, 0, len(result.ByTrack))
	for name := range result.ByTrack {
		names = append(names, name)
	}
	sort.Strings(names)
	return names
}
