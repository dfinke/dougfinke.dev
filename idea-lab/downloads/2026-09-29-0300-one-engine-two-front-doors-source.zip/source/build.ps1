#requires -Version 7.0
[CmdletBinding()]
param()

# Stop when Go is not installed so no partial output is produced.
$go = Get-Command go -ErrorAction SilentlyContinue
if (-not $go) {
    throw 'Install Go 1.24 or newer, then run this build script again.'
}

# Confirm that the Wails v2 build command is available.
$wails = Get-Command wails -ErrorAction SilentlyContinue
if (-not $wails) {
    throw 'Install the Wails v2 CLI, then run this build script again.'
}

# Create a local output folder for the CLI and Wails build products.
$binPath = Join-Path $PSScriptRoot 'bin'
New-Item -ItemType Directory -Path $binPath -Force | Out-Null

# Build the PowerShell-facing JSON CLI from the shared planner package.
$cliName = if ($IsWindows) { 'plancli.exe' } else { 'plancli' }
& $go.Source build -o (Join-Path $binPath $cliName) ./cmd/plancli
if ($LASTEXITCODE -ne 0) {
    throw "Go CLI build failed with exit code $LASTEXITCODE."
}

# Build the cross-platform desktop app from the same planner package.
& $wails.Source build
if ($LASTEXITCODE -ne 0) {
    throw "Wails build failed with exit code $LASTEXITCODE."
}

# Report both build locations without executing either binary.
[pscustomobject]@{
    CliPath = Join-Path $binPath $cliName
    UiPath  = Join-Path $PSScriptRoot 'build/bin'
}
