module example.local/sessionboard

go 1.24

require github.com/wailsapp/wails/v2 v2.10.1
