package main

import (
	"encoding/json"
	"fmt"
	"os"

	"example.local/sessionboard/internal/plan"
)

// main reads one JSON request from standard input and writes one JSON result.
func main() {
	var request plan.Request
	if err := json.NewDecoder(os.Stdin).Decode(&request); err != nil {
		fmt.Fprintln(os.Stderr, "invalid session request:", err)
		os.Exit(2)
	}
	result := plan.Analyze(request)
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		fmt.Fprintln(os.Stderr, "could not write result:", err)
		os.Exit(3)
	}
}
