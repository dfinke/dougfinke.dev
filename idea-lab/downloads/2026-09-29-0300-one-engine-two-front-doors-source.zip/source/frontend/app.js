// Ask the Go Wails binding for the same demo data used by the local CLI.
window.go.main.App.GetDemoPlan().then(function (result) {
  const summary = document.getElementById("summary");
  const tracks = document.getElementById("tracks");
  summary.textContent = result.count + " sessions · " + result.totalMinutes + " total minutes";
  Object.keys(result.byTrack).sort().forEach(function (track) {
    const row = document.createElement("p");
    row.className = "track-row";
    row.textContent = track + " · " + result.byTrack[track] + " minutes";
    tracks.appendChild(row);
  });
}).catch(function () {
  document.getElementById("summary").textContent = "Could not load the demo plan.";
});
