package main

import (
	"embed"

	"example.local/sessionboard/internal/plan"
	"github.com/wailsapp/wails/v2"
	"github.com/wailsapp/wails/v2/pkg/options"
	"github.com/wailsapp/wails/v2/pkg/options/assetserver"
)

//go:embed frontend/*
var frontend embed.FS

// App exposes the shared planning result to the Wails frontend.
type App struct{}

// GetDemoPlan returns fictional data using the same planner as the CLI.
func (a *App) GetDemoPlan() plan.Result {
	return plan.Analyze(plan.DemoRequest())
}

func main() {
	app := &App{}
	err := wails.Run(&options.App{
		Title:  "Session Board",
		Width:  900,
		Height: 650,
		AssetServer: &assetserver.Options{
			Assets: frontend,
		},
		Bind: []interface{}{app},
	})
	if err != nil {
		println("Wails app failed:", err.Error())
	}
}
