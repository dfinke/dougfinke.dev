# One Engine, Two Front Doors

A source-only Wails desktop window and a PowerShell-friendly CLI share one Go planning engine. The UI is for quick visual browsing; PowerShell can pass a structured session plan to the CLI and receive JSON back.

## Build locally

1. Install Go 1.24 or newer.
2. Install the Wails v2 CLI using the official Wails installation guide.
3. From this folder, run ./build.ps1 on PowerShell 7. It builds the CLI and launches the Wails build.
4. The generated binaries go under bin/ and are not part of this source bundle.

The Wails build downloads Go modules as part of local setup. The PowerShell runner itself does not download dependencies or call the network.

## JSON contract

PowerShell writes a request with a sessions array containing name, track, and minutes to the CLI's standard input. The CLI returns a JSON summary with session count, total minutes, and a breakdown by track. The Wails screen calls the same Go planner package.

